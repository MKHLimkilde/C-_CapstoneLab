// Workshop.cpp

#include "Workshop.h"

Workshop::Workshop(int num, const std::string& title, int hours, int capacity, double price)
    : number(num), title(title), hours(hours), capacity(capacity), price(price) {
}

int Workshop::getNumber() const { return number; }
std::string Workshop::getTitle() const { return title; }
int Workshop::getHours() const { return hours; }
int Workshop::getCapacity() const { return capacity; }
double Workshop::getPrice() const { return price; }

bool Workshop::operator<(const Workshop& other) const {
    return number < other.number;
}
