/*
    Hauen-Limkilde, Marcus

    Spring 2025
    CS A250 - C++ 2

    ParticipantList.h
*/
#include "DataLoader.h"
#include "WorkshopList.h"
#include <fstream>
#include <sstream>
#include <stdexcept>

// Implement the static method of DataLoader
void DataLoader::loadWorkshops(WorkshopList& workshopList, const std::string& filename)
{
    std::ifstream inFile(filename);
    if (!inFile)
    {
        throw std::runtime_error("Error: Unable to open file " + filename);
    }

    std::string line;
    while (std::getline(inFile, line))
    {
        std::istringstream ss(line);
        std::string token;

        int number, hours, capacity;
        std::string title;
        double price;

        std::getline(ss, token, '|');
        number = std::stoi(token);

        std::getline(ss, title, '|');

        std::getline(ss, token, '|');
        hours = std::stoi(token);

        std::getline(ss, token, '|');
        capacity = std::stoi(token);

        std::getline(ss, token, '|');
        price = std::stod(token);

        workshopList.addWorkshop(Workshop(number, title, hours, capacity, price));
    }

    inFile.close();
}
