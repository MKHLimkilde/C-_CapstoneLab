/*
    Williams, Noah (Team Leader)

    Spring 2025
    CS A250 - C++ 2

    Participant.h
*/

#include "DataLoader.h"
#include "WorkshopList.h"
#include <iostream>

int main() {
    using namespace std;

    WorkshopList workshopList;

    try {
        DataLoader::loadWorkshops(workshopList, "workshop_database.txt");

        if (workshopList.isEmpty()) {
            cout << "No workshops found in the file.\n";
        }
        else {
            cout << "Workshops loaded successfully:\n\n";

            int numbersToTry[] = { 11111, 22222, 33333 };

            for (int num : numbersToTry) {
                try {
                    cout << "Workshop Number: " << num << '\n';
                    cout << "Title         : " << workshopList.getTitle(num) << '\n';
                    cout << "Hours         : " << workshopList.getHours(num) << '\n';
                    cout << "Capacity      : " << workshopList.getCapacity(num) << '\n';
                    cout << "Price         : $" << workshopList.getPrice(num) << "\n\n";
                }
                catch (const std::exception& e) {
                    cout << "Workshop " << num << " not found.\n";
                }
            }
        }
    }
    catch (const std::exception& e) {
        cerr << e.what() << endl;
    }

    return 0;
}
