/*
    Hauen-Limkilde, Marcus

    Spring 2025
    CS A250 - C++ 2

    Workshop.h
*/
#ifndef WORKSHOP_H
#define WORKSHOP_H

#include <string>

class Workshop {
public:
    Workshop(int theNumber, const std::string& theTitle, int theHours,
        int theCapacity, double thePrice);

    int getNumber() const;
    std::string getTitle() const;
    int getHours() const;
    int getCapacity() const;
    double getPrice() const;

    bool operator<(const Workshop& other) const;

private:
    int number;
    std::string title;
    int hours;
    int capacity;
    double price;
};

#endif
