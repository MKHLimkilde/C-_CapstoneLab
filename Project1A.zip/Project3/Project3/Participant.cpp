
#include "Participant.h"

Participant::Participant(int id, const std::string& firstName, const std::string& lastName)
    : id(id), firstName(firstName), lastName(lastName) {
}

int Participant::getID() const { return id; }
std::string Participant::getFirstName() const { return firstName; }
std::string Participant::getLastName() const { return lastName; }

bool Participant::operator<(const Participant& other) const 
{
    return id < other.id;
}
