/*
    Williams, Noah (Team Leader)

    Spring 2025
    CS A250 - C++ 2

    Participant.h
*/
#ifndef PARTICIPANT_H
#define PARTICIPANT_H

#include <string>

class Participant
{
public:
    Participant(int id, const std::string& theFirstName, const std::string& theLastName);

    int getID() const;
    std::string getFirstName() const;
    std::string getLastName() const;

    bool operator<(const Participant& other) const;

private:
    int id;
    std::string firstName;
    std::string lastName;
};

#endif
