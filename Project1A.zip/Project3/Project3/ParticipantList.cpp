/*
    Ayala, Ruben

    Spring 2025
    CS A250 - C++ 2

    ParticipantList.cpp
*/


#include "ParticipantList.h"
#include <algorithm> // for std::find_if

void ParticipantList::addParticipant(const Participant& participant)
{
    participantList.insert({ participant, {} });
}

void ParticipantList::addWorkshopToParticipant(const Participant& participant, const Workshop& workshop)
{
    participantList[participant].push_back(workshop);
}

int ParticipantList::getID(const Participant& participant) const
{
    return participant.getID();
}

std::string ParticipantList::getFirstName(int participantID) const
{
    auto it = findByID(participantID);
    return it->first.getFirstName();
}

std::string ParticipantList::getLastName(int participantID) const
{
    auto it = findByID(participantID);
    return it->first.getLastName();
}

std::vector<Workshop> ParticipantList::getWorkshops(int participantID) const
{
    auto it = findByID(participantID);
    return it->second;
}

bool ParticipantList::isEmpty() const
{
    return participantList.empty();
}

void ParticipantList::clearList()
{
    participantList.clear();
}

std::map<Participant, std::vector<Workshop>>::const_iterator
ParticipantList::findByID(int participantID) const
{
    return std::find_if(participantList.begin(), participantList.end(),
        [participantID](const std::pair<Participant, std::vector<Workshop>>& entry)
        {
            return entry.first.getID() == participantID;
        });
}