/*
    Hauen-Limkilde, Marcus

    Spring 2025
    CS A250 - C++ 2

    DataLoader.h
*/

#ifndef DATALOADER_H
#define DATALOADER_H

#include <string>
#include "WorkshopList.h"  // Make sure this is included to use WorkshopList

class DataLoader {
public:
    static void loadWorkshops(WorkshopList& workshopList, const std::string& filename);
};

#endif
